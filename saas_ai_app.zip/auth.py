from flask import Blueprint, render_template, request, redirect, session, url_for
from db import add_user, get_user
import hashlib

auth_bp = Blueprint('auth', __name__)

def hash_pw(pw):
    return hashlib.sha256(pw.encode()).hexdigest()

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form['email']
        pw = hash_pw(request.form['password'])
        add_user(email, pw)
        return redirect('/login')
    return render_template('register.html')

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        pw = hash_pw(request.form['password'])
        user = get_user(email)
        if user and user[2] == pw:
            session['user_id'] = user[0]
            session['email'] = user[1]
            return redirect('/dashboard')
    return render_template('login.html')

@auth_bp.route('/logout')
def logout():
    session.clear()
    return redirect('/login')
