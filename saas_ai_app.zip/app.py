from flask import Flask, render_template, request, session, redirect
from auth import auth_bp
from appointments import handle_appointment
from db import init_db
from dotenv import load_dotenv
import os

load_dotenv()
app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET")

app.register_blueprint(auth_bp)

init_db()

@app.route('/')
def home():
    return redirect('/login')

@app.route('/dashboard', methods=['GET', 'POST'])
def dashboard():
    if 'user_id' not in session:
        return redirect('/login')
    response = None
    if request.method == 'POST':
        message = request.form['message']
        response = handle_appointment(session['user_id'], message)
    return render_template('dashboard.html', email=session['email'], response=response)
