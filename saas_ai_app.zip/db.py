import sqlite3

def init_db():
    conn = sqlite3.connect('saas.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE,
        password TEXT
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS appointments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        datetime TEXT,
        FOREIGN KEY(user_id) REFERENCES users(id)
    )''')
    conn.commit()
    conn.close()

def add_user(email, password):
    conn = sqlite3.connect('saas.db')
    c = conn.cursor()
    c.execute("INSERT INTO users (email, password) VALUES (?, ?)", (email, password))
    conn.commit()
    conn.close()

def get_user(email):
    conn = sqlite3.connect('saas.db')
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE email = ?", (email,))
    user = c.fetchone()
    conn.close()
    return user

def add_appointment(user_id, dt):
    conn = sqlite3.connect('saas.db')
    c = conn.cursor()
    c.execute("INSERT INTO appointments (user_id, datetime) VALUES (?, ?)", (user_id, dt))
    conn.commit()
    conn.close()

def get_appointments(user_id):
    conn = sqlite3.connect('saas.db')
    c = conn.cursor()
    c.execute("SELECT datetime FROM appointments WHERE user_id = ?", (user_id,))
    data = c.fetchall()
    conn.close()
    return data
