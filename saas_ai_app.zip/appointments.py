from datetime import datetime
from db import add_appointment, get_appointments

def handle_appointment(user_id, message):
    if "schedule" in message:
        dt = datetime.now().strftime("%Y-%m-%d %H:%M")
        add_appointment(user_id, dt)
        return f"Appointment scheduled for {dt}"
    elif "view" in message:
        appts = get_appointments(user_id)
        return "\n".join([a[0] for a in appts]) or "No appointments yet."
    else:
        return "Sorry, I didn't understand that."
